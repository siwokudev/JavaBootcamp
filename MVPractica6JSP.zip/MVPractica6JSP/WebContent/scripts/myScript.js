window.onload = function(){
    alert("Hola mundo");
}