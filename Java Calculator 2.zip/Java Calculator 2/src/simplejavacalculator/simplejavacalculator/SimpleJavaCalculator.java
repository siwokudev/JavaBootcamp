package simplejavacalculator;

public class SimpleJavaCalculator {

    public static void main(String[] args) {
        CalculatorView calculatorViewCal = new CalculatorView();
        calculatorViewCal.init();
    }

}
